exports.mySampleTime = function () {
    return Date();
};