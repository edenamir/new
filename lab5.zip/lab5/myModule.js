console.log("In a module.");

function myFunction() {
    console.log("Eden is writing to log.");
    return ("Eden is writing to respond.");
}
module.exports = myFunction;
